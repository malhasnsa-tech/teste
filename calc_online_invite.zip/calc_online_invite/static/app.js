function brl(v){ return v.toLocaleString('pt-BR',{style:'currency',currency:'BRL'}); }
function round90(v){ const x = Math.round(v); const base = (x <= v ? x : x-1); return Math.max(0, base) + 0.90; }
function ler(n){ const el=document.getElementById(n); return el?parseFloat(el.value||'0'):0; }
function setText(id, text){ const el=document.getElementById(id); if(el){ el.textContent = text; } }

function calcular(){
  const cp = ler('custo_produto');
  const cf = ler('custo_frete');
  const ce = ler('custo_embalagem');
  const co = ler('custo_operacao');
  const txp = ler('tx_shopee_pct')/100;
  const txf = ler('tx_shopee_fix');
  const tap = ler('tx_antecipa_pct')/100;
  const imp = ler('imposto_pct')/100;
  const m   = ler('margem_liq_pct')/100;

  const custos = cp+cf+ce+co;
  const denom = 1 - txp - tap - imp - m;
  const precoSugerido = denom>0 ? (custos + txf)/denom : 0;

  setText('preco_sugerido', brl(precoSugerido));

  let P = ler('preco_definido');
  if(!P || P<=0){ P = precoSugerido; const inpt=document.getElementById('preco_definido'); if(inpt) inpt.value = P.toFixed(2); }

  const taxaPctR$ = P*txp;
  const taxaAntR$ = P*tap;
  const impostoR$ = P*imp;
  const faturLiquido = P - (taxaPctR$ + taxaAntR$ + impostoR$ + txf);
  const lucro = faturLiquido - custos;
  const margemLiq = P>0 ? (lucro/P) : 0;

  const tbody = document.querySelector('#tabela_resumo tbody');
  if(tbody){
    tbody.innerHTML = `
      <tr><td>Preço de venda</td><td class="mono">${brl(P)}</td></tr>
      <tr><td>Taxa Shopee (%)</td><td class="mono">-${brl(taxaPctR$)}</td></tr>
      <tr><td>Taxa Shopee (fixa)</td><td class="mono">-${brl(txf)}</td></tr>
      <tr><td>Antecipa (%)</td><td class="mono">-${brl(taxaAntR$)}</td></tr>
      <tr><td>Imposto (%)</td><td class="mono">-${brl(impostoR$)}</td></tr>
      <tr><td><b>Faturamento líquido</b></td><td class="mono"><b>${brl(faturLiquido)}</b></td></tr>
      <tr><td>Custos (produto+frete+emb.+op.)</td><td class="mono">-${brl(custos)}</td></tr>
    `;
  }
  setText('lucro_liq', brl(lucro));
  setText('margem_liq', (margemLiq*100).toFixed(2).replace('.',',')+'%');

  const alerta = document.getElementById('alerta');
  if(alerta){
    if(lucro<0){ alerta.textContent = 'Preço atual gera prejuízo'; alerta.className='pill bad'; }
    else if(margemLiq < m){ alerta.textContent = 'Abaixo da margem alvo'; alerta.className='pill warn'; }
    else { alerta.textContent = 'OK: atende a margem alvo'; alerta.className='pill ok'; }
  }

  const promocao = round90(precoSugerido);
  const cheio = round90(precoSugerido*2);
  setText('preco_promocao', brl(promocao));
  setText('preco_cheio', brl(cheio));
}
function usarSugerido(){
  const txt = document.getElementById('preco_sugerido')?.textContent?.replace(/[^\d,.-]/g,'');
  const valor = txt?parseFloat(txt.replace('.','').replace(',','.')):0;
  if(valor){ const inpt=document.getElementById('preco_definido'); if(inpt){ inpt.value = valor.toFixed(2); calcular(); } }
}
function limpar(){
  ['custo_produto','custo_frete','custo_embalagem','custo_operacao','tx_shopee_fix','preco_definido','concorrencia'].forEach(id=>{
    const el=document.getElementById(id); if(el) el.value = '0.00';
  });
  ['tx_shopee_pct','tx_antecipa_pct','imposto_pct','margem_liq_pct'].forEach(id=>{ const el=document.getElementById(id); if(el) el.value='0.0'; });
  calcular();
}
function presetExemplo(){
  const set=(id,v)=>{const el=document.getElementById(id); if(el) el.value=v;};
  set('custo_produto','22.00'); set('custo_frete','0.00'); set('custo_embalagem','0.50'); set('custo_operacao','1.00');
  set('tx_shopee_pct','20.0'); set('tx_shopee_fix','4.00'); set('tx_antecipa_pct','0.0'); set('imposto_pct','4.5'); set('margem_liq_pct','20.0');
  set('preco_definido','49.90'); calcular();
}
document.addEventListener('input', e=>{ if(e.target.tagName==='INPUT') calcular(); });
document.addEventListener('DOMContentLoaded', presetExemplo);
